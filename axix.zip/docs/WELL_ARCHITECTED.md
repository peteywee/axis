# Well-Architected Checklist
- Operational Excellence
- Security
- Reliability
- Performance Efficiency
- Cost Optimization
- Compliance by Design