# Axis Scaffold
Compliance-first PWA with React, Vite, Firebase, and Tailwind.